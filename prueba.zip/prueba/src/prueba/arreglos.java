package prueba;

import java.util.Scanner;

public class arreglos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s=new Scanner(System.in);
		int A[], B[], n;
		int producto=0;
		
		System.out.println("Ingrese el tamaño de los arreglos");
		n=s.nextInt();
		
		A=new int[n];
		B=new int[n];
		
		for(int i=0; i<n; i++) {
			System.out.println("Ingrese el valor #"+(i+1)+" de A");
            A[i]=s.nextInt();
			System.out.println("Ingrese el valor #"+(i+1)+" de B");
            B[i]=s.nextInt();
            
            producto+= A[i]*B[i];
			
			
		} 
		
		
		System.out.println("El producto punto es: "+producto);
	}

}
